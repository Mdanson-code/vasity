#!/bin/bash

# Start Vasiti Backend Development Server

echo "🚀 Starting Vasiti Backend..."

BACKEND_PATH="$PWD/vasiti-backend"

if [ -d "$BACKEND_PATH" ]; then
    cd "$BACKEND_PATH"
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        echo "⚠️  Dependencies not installed. Running npm install..."
        npm install
    fi
    
    # Check if .env exists
    if [ ! -f ".env" ]; then
        echo "❌ .env file not found!"
        echo "Please copy .env.example to .env and fill in your credentials"
        exit 1
    fi
    
    echo "✅ Starting backend server at http://localhost:3000/api"
    echo "Press Ctrl+C to stop"
    echo ""
    
    npm run dev
else
    echo "❌ Backend folder not found at $BACKEND_PATH"
fi
