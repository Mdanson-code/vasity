# Start Mobile App Development Server
Write-Host "📱 Starting Vasiti Mobile App..." -ForegroundColor Cyan

$appPath = "c:\Users\kevooh\Desktop\vasiti\vasiti-app"

if (Test-Path $appPath) {
    Set-Location $appPath
    
    # Check if node_modules exists
    if (-not (Test-Path "node_modules")) {
        Write-Host "⚠️  Dependencies not installed. Running npm install..." -ForegroundColor Yellow
        npm install
    }
    
    Write-Host "✅ Starting Expo development server..." -ForegroundColor Green
    Write-Host "Scan the QR code with Expo Go app on your phone" -ForegroundColor Gray
    Write-Host "Or press 'a' for Android emulator`n" -ForegroundColor Gray
    
    npx expo start
} else {
    Write-Host "❌ Mobile app folder not found at $appPath" -ForegroundColor Red
}
