#!/bin/bash

# Vasiti - Complete Build & Deploy Script for Linux
# This script prepares everything for production deployment

set -e  # Exit on error

echo "🚀 Vasiti - Production Build Script"
echo "======================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found${NC}"
    echo "Install from: https://nodejs.org/"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node --version)${NC}"
echo -e "${GREEN}✅ npm $(npm --version)${NC}"
echo ""

# Backend Build
echo "================================"
echo "📦 Building Backend..."
echo "================================"
cd vasiti-backend

if [ ! -f ".env" ]; then
    echo -e "${RED}❌ .env file missing!${NC}"
    echo "Copy .env.example to .env and configure it"
    exit 1
fi

echo "Installing dependencies..."
npm install --production=false

echo "Generating Prisma client..."
npx prisma generate

echo "Building TypeScript..."
npm run build

echo -e "${GREEN}✅ Backend build complete!${NC}"
echo ""

# Mobile App Build
cd ../vasiti-app
echo "================================"
echo "📱 Preparing Mobile App..."
echo "================================"

echo "Installing dependencies..."
npm install

echo -e "${GREEN}✅ Mobile app ready!${NC}"
echo ""

# Summary
cd ..
echo "======================================"
echo "🎉 Build Complete!"
echo "======================================"
echo ""

echo -e "${GREEN}Next Steps:${NC}"
echo ""
echo "1️⃣  Deploy Backend:"
echo "   - Push to GitHub"
echo "   - Deploy on Railway.app"
echo "   - Add environment variables"
echo "   - Run: npx prisma migrate deploy"
echo ""

echo "2️⃣  Build Mobile App:"
echo "   cd vasiti-app"
echo "   eas build --platform android --profile production"
echo ""

echo "3️⃣  Test Everything:"
echo "   - Backend: http://localhost:3000/api"
echo "   - Mobile: npx expo start"
echo ""

echo -e "${YELLOW}📚 Documentation:${NC}"
echo "   - LINUX-SETUP.md - Linux setup guide"
echo "   - DEPLOYMENT.md - Production deployment"
echo "   - PRODUCTION-READY.md - Launch checklist"
echo ""

echo -e "${GREEN}✨ Your app is ready for deployment!${NC}"
