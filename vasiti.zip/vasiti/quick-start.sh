#!/bin/bash

# Vasiti Quick Start Setup Script for Linux
# Run this script after installing Node.js

echo "🚀 Vasiti Quick Start Setup"
echo "================================"
echo ""

# Check Node.js installation
echo "Checking Node.js installation..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo "✅ Node.js $NODE_VERSION installed"
else
    echo "❌ Node.js not found. Please install from https://nodejs.org/"
    echo "After installing, restart your terminal and run this script again."
    exit 1
fi

# Check npm
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    echo "✅ npm $NPM_VERSION installed"
    echo ""
else
    echo "❌ npm not found"
    exit 1
fi

# Setup Backend
echo "================================"
echo "📦 Setting up Backend..."
echo "================================"
echo ""

BACKEND_PATH="$PWD/vasiti-backend"
if [ -d "$BACKEND_PATH" ]; then
    cd "$BACKEND_PATH"
    
    echo "Installing backend dependencies... (this may take a few minutes)"
    npm install
    
    if [ -f ".env" ]; then
        echo "✅ .env file exists"
    else
        echo "⚠️  Creating .env file from .env.example..."
        cp ".env.example" ".env"
        echo "✅ .env file created. Please edit it with your credentials."
    fi
    
    echo ""
    echo "Generating Prisma client..."
    npx prisma generate
    
    echo ""
    echo "✅ Backend setup complete!"
else
    echo "❌ Backend folder not found at $BACKEND_PATH"
fi

echo ""
echo "================================"
echo "📱 Setting up Mobile App..."
echo "================================"
echo ""

APP_PATH="$PWD/vasiti-app"
if [ -d "$APP_PATH" ]; then
    cd "$APP_PATH"
    
    echo "Installing mobile app dependencies... (this may take a few minutes)"
    npm install
    
    echo ""
    echo "✅ Mobile app setup complete!"
else
    echo "❌ Mobile app folder not found at $APP_PATH"
fi

# Summary
echo ""
echo "================================"
echo "🎉 Setup Complete!"
echo "================================"
echo ""

echo "Next Steps:"
echo "1. Set up PostgreSQL database"
echo "   - Option A: Install locally from https://www.postgresql.org/"
echo "   - Option B: Use Supabase (free): https://supabase.com"
echo ""

echo "2. Update backend .env file:"
echo "   cd vasiti-backend"
echo "   nano .env"
echo "   # Add your DATABASE_URL and other credentials"
echo ""

echo "3. Run database migrations:"
echo "   cd vasiti-backend"
echo "   npx prisma migrate dev"
echo ""

echo "4. Start backend server:"
echo "   cd vasiti-backend"
echo "   npm run dev"
echo "   # Backend will run at http://localhost:3000/api"
echo ""

echo "5. Start mobile app (in new terminal):"
echo "   cd vasiti-app"
echo "   npx expo start"
echo "   # Scan QR code with Expo Go app"
echo ""

echo "📚 Documentation:"
echo "   - SETUP-INSTRUCTIONS.md - Complete setup guide"
echo "   - DEPLOYMENT.md - Production deployment"
echo "   - README.md - Project overview"
echo ""

echo "Need help? Check SETUP-INSTRUCTIONS.md"
