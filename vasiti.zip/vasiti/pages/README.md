# Vasiti - Student Marketplace & Social Platform

A vibrant mobile-first web application designed for university students to connect, buy, sell, and socialize on campus.

## 📱 Features

### Onboarding
- 3-step onboarding flow introducing students to the platform
- "Connect & Inspire" messaging with vibrant imagery
- Progressive indicators and smooth transitions

### Home Feed
- Instagram-like social feed with stories
- Post interactions (likes, comments, shares, bookmarks)
- User-generated content display
- 7 different feed variants

### Marketplace
- **Product Details**: Full item listings with image carousel, pricing in ₦, ratings
- **New Listing**: Multi-step form to sell items (photos, title, price, category, condition, description)
- **My Listings**: Manage your posted items with status tracking
- **Categories**: Browse products by category
- **Buying History**: View transaction records

### Social Features
- **Create Post**: Share content with the community
- **Seller Profile**: View seller information and ratings
- **Notifications**: Activity updates and alerts
- **Event Details**: Campus events and activities

### Settings & Privacy
- Account management
- Password changes
- Payment methods configuration

## 🎨 Design System

### Colors
- **Primary**: `#f45925` (Vibrant Orange)
- **Primary Light**: `#ff8c5a`
- **Background Light**: `#ffffff` / `#f8f6f5`
- **Background Dark**: `#121212` / `#221410`
- **Text Main**: `#181311`

### Typography
- **Display Font**: Epilogue (Headers)
- **Body Font**: Lato (Body Text)

### Border Radius
- Default: `0.5rem`
- Large: `1rem`
- XL: `1.5rem`
- 2XL: `2rem`
- Full: `9999px`

## 🛠 Tech Stack

- **HTML5**: Semantic markup
- **Tailwind CSS**: Utility-first CSS framework (via CDN)
- **Google Fonts**: Epilogue & Lato
- **Material Symbols**: Icon library
- **Responsive Design**: Mobile-first (max-width: 448px/md)
- **Dark Mode**: Full support throughout

## 📁 Project Structure

```
vasiti/
├── index.html              # Landing page with navigation
├── pages/
│   ├── onboarding-1.html
│   ├── onboarding-2.html
│   ├── onboarding-3.html
│   ├── home-feed-1.html
│   ├── home-feed-2.html
│   ├── home-feed-3.html
│   ├── home-feed-4.html
│   ├── home-feed-5.html
│   ├── home-feed-6.html
│   ├── home-feed-7.html
│   ├── product-details.html
│   ├── new-listing.html
│   ├── my-listings.html
│   ├── categories.html
│   ├── buying-history.html
│   ├── create-post.html
│   ├── seller-profile.html
│   ├── settings.html
│   ├── notifications.html
│   └── event-details.html
├── assets/                 # (Future: Images, icons, etc.)
└── stitch_vasiti/         # Original Stitch export files
```

## 🚀 Getting Started

1. Open `index.html` in your web browser
2. Navigate through the different sections using the page directory
3. Best viewed at mobile viewport (375px-428px width)

## 📱 Viewing Instructions

### Desktop Browser
1. Open Developer Tools (F12)
2. Toggle Device Toolbar (Ctrl+Shift+M / Cmd+Shift+M)
3. Select a mobile device (iPhone 12/13 Pro recommended)
4. Navigate to `index.html`

### Mobile Device
Simply open `index.html` directly on your mobile browser for the best experience.

## 🎯 Key Interactions

- **Stories**: Tap to view user stories (horizontal scroll)
- **Posts**: Like, comment, share, and bookmark
- **Navigation**: Bottom navigation bar for main sections
- **FAB**: Floating Action Button for creating posts/listings
- **Dark Mode**: System preference detection (supports toggle)

## 🔧 Customization

All pages use Tailwind CSS configuration embedded in the `<script>` tags. To customize:

1. Modify the `tailwind.config` object in any HTML file
2. Update color values in the `colors` object
3. Adjust font families in the `fontFamily` object
4. Change border radius values in the `borderRadius` object

## 📝 Notes

- **Currency**: Nigerian Naira (₦)
- **Target Audience**: University students in Nigeria
- **Design Style**: Gallery aesthetic with vibrant colors
- **Images**: Hosted on Google Cloud (lh3.googleusercontent.com)
- **Static Prototype**: No backend integration (frontend only)

## 🌟 Features to Implement (Future)

- [ ] Backend API integration
- [ ] User authentication
- [ ] Real-time messaging
- [ ] Payment gateway integration
- [ ] Image upload functionality
- [ ] Search and filters
- [ ] Push notifications
- [ ] Analytics tracking

## 📄 License

This is a design prototype for educational purposes.

## 👥 Credits

- Design: Stitch Design System
- Development: Vasiti Team
- Created: December 2025

---

**Built with ❤️ for university students**
