import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const categories = [
  { id: '1', name: 'Electronics', icon: 'laptop-outline', count: 342 },
  { id: '2', name: 'Fashion & Clothing', icon: 'shirt-outline', count: 567 },
  { id: '3', name: 'Books & Stationery', icon: 'book-outline', count: 234 },
  { id: '4', name: 'Furniture', icon: 'bed-outline', count: 89 },
  { id: '5', name: 'Sports & Fitness', icon: 'football-outline', count: 156 },
  { id: '6', name: 'Food & Drinks', icon: 'fast-food-outline', count: 201 },
  { id: '7', name: 'Beauty & Health', icon: 'heart-outline', count: 178 },
  { id: '8', name: 'Home Appliances', icon: 'home-outline', count: 134 },
  { id: '9', name: 'Music & Arts', icon: 'musical-notes-outline', count: 92 },
  { id: '10', name: 'Automotive', icon: 'car-outline', count: 67 },
  { id: '11', name: 'Phones & Tablets', icon: 'phone-portrait-outline', count: 445 },
  { id: '12', name: 'Services', icon: 'people-outline', count: 123 },
];

export default function CategoriesScreen({ navigation }: any) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = categories.filter((cat) =>
    cat.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const renderCategory = ({ item }: any) => (
    <TouchableOpacity
      style={styles.categoryCard}
      onPress={() => navigation.navigate('Home', { category: item.name })}
      activeOpacity={0.7}
    >
      <View style={styles.iconContainer}>
        <Ionicons name={item.icon as any} size={32} color="#f45925" />
      </View>
      <View style={styles.categoryInfo}>
        <Text style={styles.categoryName}>{item.name}</Text>
        <Text style={styles.categoryCount}>{item.count} items</Text>
      </View>
      <Ionicons name="chevron-forward" size={20} color="#8a6b60" />
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Categories</Text>
        <Text style={styles.headerSubtitle}>Browse by category</Text>
      </View>

      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#8a6b60" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search categories..."
          placeholderTextColor="#8a6b60"
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <Ionicons name="close-circle" size={20} color="#8a6b60" />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={filteredCategories}
        renderItem={renderCategory}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#181311',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#8a6b60',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    marginHorizontal: 20,
    marginVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 12,
    height: 48,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#181311',
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f0f0f0',
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: '#fff5f2',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#181311',
    marginBottom: 4,
  },
  categoryCount: {
    fontSize: 14,
    color: '#8a6b60',
  },
});
