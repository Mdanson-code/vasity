import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const stories = [
  { id: '1', name: 'My Story', image: 'https://i.pravatar.cc/150?img=1', isOwn: true },
  { id: '2', name: 'Jada', image: 'https://i.pravatar.cc/150?img=5', hasStory: true },
  { id: '3', name: 'Marcus', image: 'https://i.pravatar.cc/150?img=12', hasStory: true },
  { id: '4', name: 'Ebony', image: 'https://i.pravatar.cc/150?img=9', hasStory: true },
  { id: '5', name: 'Trey', image: 'https://i.pravatar.cc/150?img=13', hasStory: false },
];

const posts = [
  {
    id: '1',
    user: { name: 'Amara K.', avatar: 'https://i.pravatar.cc/150?img=5' },
    image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800',
    likes: 245,
    comments: 12,
    caption: 'Study vibes @ the union #VasityLife 📚✨',
    time: '2h ago',
    location: 'Campus',
  },
  {
    id: '2',
    user: { name: 'Marcus T.', avatar: 'https://i.pravatar.cc/150?img=12' },
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=800',
    likes: 892,
    comments: 45,
    caption: 'Weekend inspiration. The colors here are insane! 🎨🔥',
    time: '5h ago',
    location: 'Art Gallery',
    liked: true,
  },
];

export default function HomeFeedScreen({ navigation }: any) {
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set(['2']));

  const toggleLike = (postId: string) => {
    const newLiked = new Set(likedPosts);
    if (newLiked.has(postId)) {
      newLiked.delete(postId);
    } else {
      newLiked.add(postId);
    }
    setLikedPosts(newLiked);
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>VASITI</Text>
        <TouchableOpacity style={styles.notificationButton}>
          <Ionicons name="notifications-outline" size={28} color="#181311" />
          <View style={styles.notificationDot} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Stories */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.storiesContainer}
          contentContainerStyle={styles.storiesContent}
        >
          {stories.map((story) => (
            <TouchableOpacity key={story.id} style={styles.storyItem}>
              <View style={[styles.storyRing, !story.hasStory && !story.isOwn && styles.noStoryRing]}>
                <Image source={{ uri: story.image }} style={styles.storyImage} />
                {story.isOwn && (
                  <View style={styles.addStoryButton}>
                    <Ionicons name="add" size={12} color="white" />
                  </View>
                )}
              </View>
              <Text style={styles.storyName}>{story.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Posts */}
        {posts.map((post) => (
          <View key={post.id} style={styles.post}>
            {/* Post Header */}
            <View style={styles.postHeader}>
              <View style={styles.postUser}>
                <Image source={{ uri: post.user.avatar }} style={styles.userAvatar} />
                <View>
                  <Text style={styles.userName}>{post.user.name}</Text>
                  <Text style={styles.postTime}>
                    {post.time} • {post.location}
                  </Text>
                </View>
              </View>
              <TouchableOpacity>
                <Ionicons name="ellipsis-horizontal" size={24} color="#181311" />
              </TouchableOpacity>
            </View>

            {/* Post Image */}
            <TouchableOpacity
              onPress={() => navigation.navigate('ProductDetails', { post })}
            >
              <Image source={{ uri: post.image }} style={styles.postImage} />
            </TouchableOpacity>

            {/* Post Actions */}
            <View style={styles.postActions}>
              <View style={styles.leftActions}>
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => toggleLike(post.id)}
                >
                  <Ionicons
                    name={likedPosts.has(post.id) ? 'heart' : 'heart-outline'}
                    size={28}
                    color={likedPosts.has(post.id) ? '#f45925' : '#181311'}
                  />
                  <Text style={styles.actionText}>{post.likes}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <Ionicons name="chatbubble-outline" size={28} color="#181311" />
                  <Text style={styles.actionText}>{post.comments}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton}>
                  <Ionicons name="paper-plane-outline" size={28} color="#181311" />
                </TouchableOpacity>
              </View>
              <TouchableOpacity>
                <Ionicons name="bookmark-outline" size={28} color="#181311" />
              </TouchableOpacity>
            </View>

            {/* Caption */}
            <Text style={styles.caption}>{post.caption}</Text>
          </View>
        ))}
      </ScrollView>

      {/* FAB */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('CreatePost')}
      >
        <LinearGradient
          colors={['#f45925', '#fbbf24']}
          style={styles.fabGradient}
        >
          <Ionicons name="add" size={32} color="white" />
        </LinearGradient>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  logo: {
    fontSize: 24,
    fontWeight: '300',
    letterSpacing: 2,
    color: '#181311',
  },
  notificationButton: {
    position: 'relative',
  },
  notificationDot: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#f45925',
    borderWidth: 2,
    borderColor: 'white',
  },
  storiesContainer: {
    maxHeight: 120,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  storiesContent: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    gap: 16,
  },
  storyItem: {
    alignItems: 'center',
    marginRight: 8,
  },
  storyRing: {
    width: 76,
    height: 76,
    borderRadius: 38,
    padding: 3,
    backgroundColor: 'linear-gradient(45deg, #f45925, #fbbf24)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  noStoryRing: {
    backgroundColor: '#e0e0e0',
  },
  storyImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 2,
    borderColor: 'white',
  },
  addStoryButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#f45925',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  storyName: {
    fontSize: 12,
    marginTop: 4,
    color: '#181311',
  },
  post: {
    marginBottom: 32,
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  postUser: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  userAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  userName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#181311',
  },
  postTime: {
    fontSize: 12,
    color: '#8a6b60',
  },
  postImage: {
    width: width,
    height: width * 1.25,
    backgroundColor: '#f0f0f0',
  },
  postActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  leftActions: {
    flexDirection: 'row',
    gap: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  actionText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#181311',
  },
  caption: {
    fontSize: 16,
    color: '#181311',
    paddingHorizontal: 16,
    lineHeight: 22,
  },
  fab: {
    position: 'absolute',
    bottom: 80,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    shadowColor: '#f45925',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  fabGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
