import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const PRODUCT_DATA = {
  id: '1',
  title: 'Vintage Polaroid 600 Camera - 90s Edition',
  price: 8500, // KSh (Kenyan Shillings)
  images: [
    'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=800',
    'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800',
    'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800',
  ],
  condition: 'Pre-owned - Excellent',
  rating: 4.9,
  reviews: 24,
  description: 'Fully functional vintage camera. The flash works perfectly and the rollers are clean. It comes with the original strap and has been tested with film. There are minor scuffs on the bottom but otherwise it's in pristine condition for its age. Perfect for collectors or retro photography enthusiasts.',
  seller: {
    name: 'Tunde A.',
    avatar: 'https://i.pravatar.cc/150?img=7',
    location: 'Nairobi, Kenya',
    verified: true,
    rating: 4.9,
  },
  tags: ['Authentic', 'Vintage'],
};

export default function ProductDetailsScreen({ navigation, route }: any) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  const formatPrice = (price: number) => {
    return `KSh ${price.toLocaleString()}`;
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.headerButton}>
          <Ionicons name="arrow-back" size={24} color="#181311" />
        </TouchableOpacity>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.headerButton}>
            <Ionicons name="share-social-outline" size={24} color="#181311" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerButton}
            onPress={() => setIsFavorite(!isFavorite)}
          >
            <Ionicons
              name={isFavorite ? 'heart' : 'heart-outline'}
              size={24}
              color={isFavorite ? '#f45925' : '#181311'}
            />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Image Carousel */}
        <View style={styles.imageContainer}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(event) => {
              const index = Math.floor(
                event.nativeEvent.contentOffset.x / width
              );
              setCurrentImageIndex(index);
            }}
          >
            {PRODUCT_DATA.images.map((image, index) => (
              <Image
                key={index}
                source={{ uri: image }}
                style={styles.productImage}
                resizeMode="cover"
              />
            ))}
          </ScrollView>
          
          {/* Image Indicators */}
          <View style={styles.imageIndicators}>
            {PRODUCT_DATA.images.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.indicator,
                  index === currentImageIndex && styles.activeIndicator,
                ]}
              />
            ))}
          </View>
        </View>

        {/* Product Info */}
        <View style={styles.content}>
          <Text style={styles.title}>{PRODUCT_DATA.title}</Text>

          <View style={styles.priceRow}>
            <Text style={styles.price}>{formatPrice(PRODUCT_DATA.price)}</Text>
            <View style={styles.ratingBadge}>
              <Ionicons name="star" size={16} color="#fbbf24" />
              <Text style={styles.ratingText}>{PRODUCT_DATA.rating}</Text>
              <Text style={styles.reviewsText}>({PRODUCT_DATA.reviews})</Text>
            </View>
          </View>

          {/* Tags */}
          <View style={styles.tags}>
            <View style={[styles.tag, styles.verifiedTag]}>
              <Ionicons name="checkmark-circle" size={16} color="#10b981" />
              <Text style={styles.tagText}>Authentic</Text>
            </View>
            <View style={[styles.tag, styles.conditionTag]}>
              <Text style={styles.conditionText}>{PRODUCT_DATA.condition}</Text>
            </View>
            {PRODUCT_DATA.tags.map((tag, index) => (
              <View key={index} style={styles.tag}>
                <Text style={styles.tagText}>{tag}</Text>
              </View>
            ))}
          </View>

          {/* Description */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Description</Text>
            <Text style={styles.description}>{PRODUCT_DATA.description}</Text>
          </View>

          {/* Seller Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Sold by</Text>
            <TouchableOpacity style={styles.sellerCard}>
              <View style={styles.sellerInfo}>
                <View style={styles.avatarContainer}>
                  <Image
                    source={{ uri: PRODUCT_DATA.seller.avatar }}
                    style={styles.sellerAvatar}
                  />
                  {PRODUCT_DATA.seller.verified && (
                    <View style={styles.verifiedBadge}>
                      <Ionicons name="checkmark" size={10} color="white" />
                    </View>
                  )}
                </View>
                <View>
                  <Text style={styles.sellerName}>{PRODUCT_DATA.seller.name}</Text>
                  <View style={styles.sellerDetails}>
                    <Text style={styles.sellerLocation}>{PRODUCT_DATA.seller.location}</Text>
                    <Text style={styles.dot}>•</Text>
                    <Text style={styles.verifiedText}>Verified Seller</Text>
                  </View>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#d1d5db" />
            </TouchableOpacity>
          </View>

          {/* Money Back Guarantee */}
          <View style={styles.guarantee}>
            <Ionicons name="shield-checkmark" size={18} color="#10b981" />
            <Text style={styles.guaranteeText}>
              Vasiti Money Back Guarantee covers your purchase
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Actions */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.chatButton}>
          <Ionicons name="chatbubble-outline" size={20} color="#181311" />
          <Text style={styles.chatButtonText}>Chat</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.offerButton}>
          <LinearGradient
            colors={['#f45925', '#ff8c5a']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.offerGradient}
          >
            <Text style={styles.offerButtonText}>Make Offer</Text>
            <Ionicons name="arrow-forward" size={20} color="white" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f6f5',
  },
  headerRight: {
    flexDirection: 'row',
    gap: 8,
  },
  imageContainer: {
    width: width,
    height: width * 0.75,
    position: 'relative',
  },
  productImage: {
    width: width,
    height: width * 0.75,
  },
  imageIndicators: {
    position: 'absolute',
    bottom: 16,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
  },
  activeIndicator: {
    backgroundColor: 'white',
  },
  content: {
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '300',
    color: '#181311',
    marginBottom: 12,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  price: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#f45925',
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f6f5',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  ratingText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#181311',
  },
  reviewsText: {
    fontSize: 12,
    color: '#8a6b60',
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 24,
  },
  tag: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: '#f8f6f5',
    gap: 4,
  },
  verifiedTag: {
    backgroundColor: '#ecfdf5',
  },
  conditionTag: {
    backgroundColor: '#fff7ed',
  },
  tagText: {
    fontSize: 14,
    color: '#181311',
  },
  conditionText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#f45925',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '500',
    color: '#181311',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    color: '#635753',
  },
  sellerCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#f8f6f5',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#e6dedb',
  },
  sellerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatarContainer: {
    position: 'relative',
  },
  sellerAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: 'white',
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#10b981',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  sellerName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#181311',
  },
  sellerDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  sellerLocation: {
    fontSize: 14,
    color: '#8a6b60',
  },
  dot: {
    color: '#d1d5db',
  },
  verifiedText: {
    fontSize: 14,
    color: '#f45925',
    fontWeight: '500',
  },
  guarantee: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    opacity: 0.7,
  },
  guaranteeText: {
    fontSize: 12,
    color: '#8a6b60',
  },
  bottomBar: {
    flexDirection: 'row',
    gap: 12,
    padding: 16,
    paddingBottom: 24,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    backgroundColor: 'white',
  },
  chatButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#e6dedb',
  },
  chatButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#181311',
  },
  offerButton: {
    flex: 1,
  },
  offerGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 12,
  },
  offerButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
});
