import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

const onboardingData = [
  {
    id: 1,
    title: 'Connect & Inspire',
    description: 'Join the most vibrant community of students. Share your stories, find your tribe, and make your university days unforgettable.',
    image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800',
  },
  {
    id: 2,
    title: 'Discover Your Community',
    description: 'Connect with students, vendors, and friends on campus. Buy, sell, and socialize in a space built just for you.',
    image: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=800',
  },
  {
    id: 3,
    title: 'Your Campus, Amplified',
    description: 'Connect with students, buy and sell, and discover events happening right now. Experience university life like never before.',
    image: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800',
  },
];

export default function OnboardingScreen({ navigation }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    if (currentIndex < onboardingData.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      navigation.replace('MainTabs');
    }
  };

  const handleSkip = () => {
    navigation.replace('MainTabs');
  };

  const current = onboardingData[currentIndex];

  return (
    <View style={styles.container}>
      {/* Skip Button */}
      <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Image */}
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: current.image }}
          style={styles.image}
          resizeMode="cover"
        />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Text style={styles.title}>{current.title}</Text>
        <Text style={styles.description}>{current.description}</Text>

        {/* Indicators */}
        <View style={styles.indicators}>
          {onboardingData.map((_, index) => (
            <View
              key={index}
              style={[
                styles.indicator,
                index === currentIndex ? styles.activeIndicator : styles.inactiveIndicator,
              ]}
            />
          ))}
        </View>

        {/* Next Button */}
        <TouchableOpacity onPress={handleNext}>
          <LinearGradient
            colors={['#f45925', '#ff8c5a']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.button}
          >
            <Text style={styles.buttonText}>
              {currentIndex === onboardingData.length - 1 ? 'Get Started' : 'Next'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="white" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  skipButton: {
    position: 'absolute',
    top: 50,
    right: 24,
    zIndex: 10,
  },
  skipText: {
    color: '#8a6b60',
    fontSize: 14,
    fontWeight: 'bold',
  },
  imageContainer: {
    width: width,
    height: height * 0.5,
    marginTop: 60,
    borderRadius: 32,
    overflow: 'hidden',
    marginHorizontal: 24,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 32,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: '300',
    color: '#181311',
    textAlign: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    color: '#665a56',
    textAlign: 'center',
    lineHeight: 24,
    maxWidth: 320,
  },
  indicators: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 32,
    marginBottom: 24,
  },
  indicator: {
    height: 8,
    borderRadius: 4,
  },
  activeIndicator: {
    width: 32,
    backgroundColor: '#f45925',
  },
  inactiveIndicator: {
    width: 8,
    backgroundColor: '#e6dedb',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 48,
    borderRadius: 16,
    width: width - 48,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
