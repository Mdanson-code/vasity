module.exports = {
  content: ['./App.{js,jsx,ts,tsx}', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#f45925',
        'primary-light': '#ff8c5a',
        'background-light': '#ffffff',
        'background-dark': '#121212',
        'text-main': '#181311',
        'text-secondary': '#8a6b60',
      },
      fontFamily: {
        display: ['Epilogue'],
        body: ['Lato'],
      },
    },
  },
  plugins: [],
}
