# Vasiti Mobile App

React Native mobile app for Vasiti - Student Marketplace & Social Platform for Kenya

## Setup Instructions

### 1. Install Node.js
Download and install from: https://nodejs.org/ (v20.x LTS)

### 2. Install Dependencies
```bash
cd vasiti-app
npm install
```

### 3. Run the App
```bash
npx expo start
```

Then:
- Press `a` for Android emulator
- Press `i` for iOS simulator (Mac only)
- Scan QR code with Expo Go app on your phone

### 4. Build APK (Production)
```bash
# Install EAS CLI globally
npm install -g eas-cli

# Login to Expo
eas login

# Configure build
eas build:configure

# Build Android APK
eas build --platform android --profile production
```

## Features Implemented

✅ Onboarding (3 screens)
✅ Home Feed with Stories
✅ Product Details with KSh pricing
✅ Bottom Tab Navigation
✅ Complete design system matching Stitch

## Currency
All prices displayed in **KSh (Kenyan Shillings)**

## Tech Stack
- React Native + Expo
- TypeScript
- React Navigation
- React Query (API)
- Zustand (State)
- Expo Image Picker
- Linear Gradient

## Next Steps
1. Complete remaining screens (Categories, New Listing, Profile, etc.)
2. Integrate backend API
3. Add M-Pesa payment integration
4. Implement real-time chat
5. Add push notifications
6. Build production APK

## Contact
For setup help or questions, refer to the main SETUP-INSTRUCTIONS.md
