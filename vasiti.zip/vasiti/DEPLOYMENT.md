# Vasiti - Complete Deployment Guide

## 🚀 Full Stack Deployment (Production Ready)

This guide covers deploying both the mobile app and backend API to production in Kenya.

---

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Backend Deployment](#backend-deployment)
3. [Mobile App Build](#mobile-app-build)
4. [Database Setup](#database-setup)
5. [M-Pesa Configuration](#m-pesa-configuration)
6. [Domain & SSL](#domain--ssl)
7. [Production Checklist](#production-checklist)

---

## Prerequisites

### Required Accounts
- ✅ **Node.js** (v20.x LTS) - https://nodejs.org/
- ✅ **GitHub** account - for code hosting
- ✅ **Railway** account - for backend hosting (or Heroku/DigitalOcean)
- ✅ **Expo** account - for mobile app builds
- ✅ **Safaricom Developer** account - for M-Pesa
- ✅ **Cloudinary** account - for image storage
- ✅ **Domain name** (optional) - e.g., vasiti.co.ke

### Install Tools
```bash
npm install -g expo-cli eas-cli
eas login
```

---

## Backend Deployment

### Option 1: Railway.app (Recommended - Easiest)

#### Step 1: Push to GitHub
```bash
cd vasiti-backend
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/vasiti-backend.git
git push -u origin main
```

#### Step 2: Deploy to Railway
1. Go to https://railway.app/
2. Click **"New Project"**
3. Select **"Deploy from GitHub repo"**
4. Choose your **vasiti-backend** repository
5. Railway will auto-detect NestJS and deploy

#### Step 3: Add PostgreSQL Database
1. In Railway dashboard, click **"New"** → **"Database"** → **"PostgreSQL"**
2. Copy the **Connection URL**
3. Set environment variable: `DATABASE_URL` = connection URL

#### Step 4: Configure Environment Variables
In Railway dashboard, add these variables:

```
DATABASE_URL=postgresql://...  (from Railway PostgreSQL)
JWT_SECRET=your-random-secret-key-change-this-now
JWT_EXPIRES_IN=7d
MPESA_CONSUMER_KEY=your-key-from-safaricom
MPESA_CONSUMER_SECRET=your-secret-from-safaricom
MPESA_SHORTCODE=your-business-shortcode
MPESA_PASSKEY=your-lipa-na-mpesa-passkey
MPESA_CALLBACK_URL=https://your-api-url.railway.app/api/payments/mpesa/callback
MPESA_ENVIRONMENT=production
CLOUDINARY_CLOUD_NAME=your-cloudinary-name
CLOUDINARY_API_KEY=your-cloudinary-key
CLOUDINARY_API_SECRET=your-cloudinary-secret
FRONTEND_URL=*
PORT=3000
```

#### Step 5: Run Migrations
In Railway dashboard, go to **Settings** → **Deploy** → **Custom Start Command**:
```bash
npx prisma migrate deploy && npm run start:prod
```

#### Step 6: Get Your API URL
Railway will give you a URL like: `https://vasiti-backend-production.up.railway.app`

---

### Option 2: Heroku

```bash
# Install Heroku CLI
npm install -g heroku

# Login
heroku login

# Create app
cd vasiti-backend
heroku create vasiti-api-kenya

# Add PostgreSQL
heroku addons:create heroku-postgresql:mini

# Set environment variables
heroku config:set JWT_SECRET="your-secret"
heroku config:set MPESA_CONSUMER_KEY="your-key"
# ... (add all other variables)

# Deploy
git push heroku main

# Run migrations
heroku run npx prisma migrate deploy
```

---

## Database Setup

### Run Prisma Migrations

#### Local Development:
```bash
cd vasiti-backend
npm install
npx prisma generate
npx prisma migrate dev --name init
```

#### Production (Railway):
Migrations run automatically with custom start command.

#### Production (Manual):
```bash
npx prisma migrate deploy
```

### Verify Database
```bash
npx prisma studio
# Opens GUI at http://localhost:5555
```

---

## Mobile App Build

### Step 1: Configure API URL

Edit [vasiti-app/app.json](vasiti-app/app.json):
```json
{
  "expo": {
    "extra": {
      "apiUrl": "https://your-api-url.railway.app/api"
    }
  }
}
```

### Step 2: Configure EAS Build

```bash
cd vasiti-app
eas build:configure
```

Creates `eas.json`:
```json
{
  "build": {
    "production": {
      "android": {
        "buildType": "apk",
        "gradleCommand": ":app:assembleRelease"
      }
    }
  }
}
```

### Step 3: Build Android APK

```bash
# Install dependencies
npm install

# Build production APK
eas build --platform android --profile production
```

This will:
- Upload your code to Expo servers
- Build APK in the cloud
- Provide download link when done (usually 10-15 minutes)

### Step 4: Download APK

```bash
# After build completes, download:
eas build:list
# Click download link or:
eas build:download --platform android --latest
```

### Step 5: Test APK

1. Transfer APK to Android phone
2. Enable **"Install from Unknown Sources"** in Settings
3. Install APK
4. Test all features

---

## M-Pesa Configuration (Kenya)

### Step 1: Register on Safaricom Developer Portal

1. Go to https://developer.safaricom.co.ke/
2. Create account
3. Click **"My Apps"** → **"Create New App"**

### Step 2: Get Sandbox Credentials (For Testing)

1. Select **"Lipa Na M-Pesa Online"** product
2. Get credentials:
   - **Consumer Key**
   - **Consumer Secret**
   - **Business Shortcode**: `174379` (sandbox)
   - **Passkey**: (provided in sandbox docs)

### Step 3: Test in Sandbox

```bash
# Test phone numbers (Sandbox):
254708374149  # PIN: 1234
254708374150  # PIN: 1234

# Test with small amounts:
1 KSh - 50,000 KSh
```

### Step 4: Go Live (Production)

1. **Register for Paybill/Till Number** with Safaricom Business
2. Get production credentials:
   - Your actual **Business Shortcode**
   - Production **Consumer Key** and **Secret**
   - **Passkey**
3. Update backend `.env`:
   ```
   MPESA_ENVIRONMENT=production
   MPESA_SHORTCODE=your-actual-shortcode
   MPESA_CONSUMER_KEY=your-prod-key
   MPESA_CONSUMER_SECRET=your-prod-secret
   MPESA_PASSKEY=your-prod-passkey
   ```

### Step 5: Configure Callback URL

In Safaricom Portal:
- **Validation URL**: `https://your-api.railway.app/api/payments/mpesa/callback`
- **Confirmation URL**: `https://your-api.railway.app/api/payments/mpesa/callback`

---

## Domain & SSL

### Custom Domain (Optional)

#### Railway:
1. Buy domain (e.g., vasiti.co.ke from Safaricom Domain)
2. In Railway → **Settings** → **Domains**
3. Add custom domain
4. Update DNS records as shown
5. SSL automatically provisioned

#### Cloudflare (Free SSL):
1. Add domain to Cloudflare
2. Point DNS to Railway/Heroku
3. Enable **"Full SSL"**

---

## Production Checklist

### Security
- [ ] Change all default passwords
- [ ] Set strong `JWT_SECRET`
- [ ] Enable CORS only for your domains
- [ ] Use HTTPS everywhere
- [ ] Set up rate limiting
- [ ] Enable Prisma query logging in production

### Performance
- [ ] Enable database connection pooling
- [ ] Set up CDN for images (Cloudinary)
- [ ] Configure caching headers
- [ ] Optimize database indexes
- [ ] Enable gzip compression

### Monitoring
- [ ] Set up error tracking (Sentry)
- [ ] Configure logging (Winston)
- [ ] Set up uptime monitoring (UptimeRobot)
- [ ] Monitor M-Pesa transactions
- [ ] Set up alerts for failed payments

### App Store Submission (Future)

#### Google Play Store:
```bash
# Build AAB instead of APK
eas build --platform android --profile production
# Upload to Google Play Console
```

#### Apple App Store:
```bash
# Build for iOS
eas build --platform ios --profile production
# Upload to App Store Connect
```

---

## Costs Breakdown (Kenya)

### Monthly Costs:
- **Railway (Backend)**: $5-20/month (free for starters, scales with usage)
- **PostgreSQL Database**: Included in Railway
- **Cloudinary (Images)**: Free tier (25GB storage, 25GB bandwidth)
- **Domain (.co.ke)**: KSh 1,500/year
- **M-Pesa Charges**: 
  - Till Number: Free to register
  - Transaction fees: ~1-2% per transaction
- **Expo Build**: Free (limited builds) or $29/month unlimited

### One-Time Costs:
- Google Play Developer Account: $25 (one-time)
- Apple Developer Account: $99/year

**Total to Start**: ~$30-50/month (production-ready)

---

## Environment Variables Cheatsheet

### Backend (.env):
```bash
# Database
DATABASE_URL="postgresql://user:pass@host:5432/vasiti"

# JWT
JWT_SECRET="change-this-super-secret-key"
JWT_EXPIRES_IN="7d"

# M-Pesa
MPESA_CONSUMER_KEY="your-key"
MPESA_CONSUMER_SECRET="your-secret"
MPESA_SHORTCODE="your-shortcode"
MPESA_PASSKEY="your-passkey"
MPESA_CALLBACK_URL="https://your-api-url/api/payments/mpesa/callback"
MPESA_ENVIRONMENT="production"

# Cloudinary
CLOUDINARY_CLOUD_NAME="your-name"
CLOUDINARY_API_KEY="your-key"
CLOUDINARY_API_SECRET="your-secret"

# API
PORT=3000
FRONTEND_URL="*"
```

### Mobile App (app.json):
```json
{
  "expo": {
    "extra": {
      "apiUrl": "https://your-backend-url.railway.app/api"
    }
  }
}
```

---

## Quick Start Commands

```bash
# Backend - Install & Run
cd vasiti-backend
npm install
npx prisma generate
npx prisma migrate dev
npm run dev

# Mobile App - Install & Run
cd vasiti-app
npm install
npx expo start

# Build Production APK
cd vasiti-app
eas build --platform android --profile production

# Deploy Backend to Railway
git push railway main
```

---

## Troubleshooting

### M-Pesa Issues:
- **Error 401**: Check consumer key/secret
- **Error 500**: Verify callback URL is accessible
- **Timeout**: Ensure phone number format is `254XXXXXXXXX`
- **Test in sandbox first** before going live

### Database Connection:
- Ensure `DATABASE_URL` is correct
- Check firewall allows connections
- Verify Prisma schema matches migrations

### Build Failures:
- Clear cache: `expo start -c`
- Update dependencies: `npm update`
- Check `eas build:list` for error logs

---

## Support Resources

- **Railway Docs**: https://docs.railway.app/
- **Expo Docs**: https://docs.expo.dev/
- **M-Pesa Docs**: https://developer.safaricom.co.ke/docs
- **Prisma Docs**: https://www.prisma.io/docs

---

## Next Steps

1. ✅ Complete Node.js installation
2. ✅ Set up backend database
3. ✅ Get M-Pesa sandbox credentials
4. ✅ Build and test APK locally
5. ✅ Deploy backend to Railway
6. ✅ Build production APK with EAS
7. ✅ Go live with M-Pesa production
8. ✅ Submit to Google Play Store

---

**You now have everything needed to deploy Vasiti to production in Kenya! 🎉**

For questions or help, refer to the main [README.md](README.md) files in each folder.
