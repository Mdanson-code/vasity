# Vasiti - Kenya Student Marketplace & Social Platform

> **Production-ready mobile app** built with React Native for Android & iOS, with NestJS backend and M-Pesa integration for Kenya.

---

## 📱 What is Vasiti?

Vasiti is a **student marketplace and social platform** designed for Kenyan universities. Students can:
- 🛍️ **Buy & Sell** - List and purchase items within campus
- 📸 **Social Feed** - Share posts, stories, and connect with students
- 💬 **Chat** - Real-time messaging with buyers/sellers
- 💳 **M-Pesa Payments** - Secure mobile money transactions
- ✅ **Verified Sellers** - Build trust within the community

**Currency**: All prices in **Kenyan Shillings (KSh)**

---

## 🏗️ Project Structure

```
vasiti/
├── stitch_vasiti/          # Original Stitch HTML designs (20+ pages)
├── vasiti-app/             # React Native mobile app
│   ├── src/
│   │   ├── screens/        # All app screens
│   │   └── navigation/     # Navigation setup
│   ├── App.tsx
│   ├── package.json
│   └── app.json
├── vasiti-backend/         # NestJS backend API
│   ├── src/
│   │   ├── auth/           # Authentication & JWT
│   │   ├── products/       # Marketplace listings
│   │   ├── posts/          # Social feed
│   │   ├── orders/         # Order management
│   │   ├── messages/       # Real-time chat
│   │   ├── payments/       # M-Pesa integration
│   │   └── prisma/         # Database ORM
│   ├── prisma/schema.prisma
│   └── package.json
├── SETUP-INSTRUCTIONS.md   # Complete setup guide
├── DEPLOYMENT.md           # Production deployment guide
└── README.md               # This file
```

---

## 🚀 Quick Start

### Prerequisites
1. **Node.js** (v20.x LTS) - https://nodejs.org/
2. **PostgreSQL** (v14+) or Supabase (free)
3. **Expo CLI** (auto-installed)
4. **Android Studio** or **Expo Go** app

### For Linux/macOS/WSL:

```bash
# 1. Navigate to project
cd vasiti

# 2. Make scripts executable
chmod +x *.sh

# 3. Run automated setup
./quick-start.sh

# 4. Set up database (Supabase recommended)
# Get connection string from https://supabase.com

# 5. Configure environment
cd vasiti-backend
nano .env  # Add your credentials

# 6. Run migrations
npx prisma migrate dev --name init

# 7. Start servers
./start-backend.sh  # Terminal 1
./start-app.sh      # Terminal 2
```

See **[LINUX-SETUP.md](LINUX-SETUP.md)** for detailed Linux instructions.

### For Windows:

```powershell
# 1. Install Node.js from https://nodejs.org/

# 2. Run quick start
.\quick-start.ps1

# 3. Configure .env file
# 4. Run migrations
# 5. Start servers
.\start-backend.ps1  # Terminal 1
.\start-app.ps1      # Terminal 2
```

Backend: `http://localhost:3000/api`  
Mobile: Scan QR with **Expo Go** app

---

## 📚 Documentation

- **[SETUP-INSTRUCTIONS.md](SETUP-INSTRUCTIONS.md)** - Complete development setup
- **[DEPLOYMENT.md](DEPLOYMENT.md)** - Production deployment guide
- **[Backend README](vasiti-backend/README.md)** - API documentation
- **[Mobile App README](vasiti-app/README.md)** - App documentation

---

## 🛠️ Tech Stack

### Mobile App
- **React Native** + **Expo** ~50.0 - Cross-platform mobile
- **TypeScript** 5.3 - Type safety
- **React Navigation** 6.x - Navigation
- **React Query** 5.17 - Data fetching & caching
- **Zustand** 4.4 - State management
- **Expo Linear Gradient** - UI gradients
- **Ionicons** - Icons

### Backend
- **NestJS** 10.3 - Node.js framework
- **PostgreSQL** + **Prisma** 5.8 - Database & ORM
- **JWT** - Authentication
- **Socket.io** - Real-time messaging
- **Axios** - HTTP client
- **Bcrypt** - Password hashing

### Infrastructure
- **Railway.app** - Backend hosting (recommended)
- **Supabase** - PostgreSQL database (optional)
- **Cloudinary** - Image storage
- **M-Pesa Daraja API** - Kenya mobile payments

---

## 💳 M-Pesa Integration

Vasiti uses **Safaricom's Lipa Na M-Pesa Online** (STK Push) for payments.

### Features:
- ✅ STK Push - Customers pay with their M-Pesa PIN
- ✅ Real-time callbacks - Instant payment confirmation
- ✅ Transaction tracking - View payment history
- ✅ KSh currency - All amounts in Kenyan Shillings

### Setup:
1. Register at https://developer.safaricom.co.ke/
2. Create app and select "Lipa Na M-Pesa Online"
3. Get sandbox credentials (Consumer Key, Secret, Shortcode, Passkey)
4. Add to backend `.env` file
5. Test with sandbox phone: `254708374149` (PIN: 1234)

See [DEPLOYMENT.md](DEPLOYMENT.md) for full M-Pesa setup guide.

---

## 📱 Features

### Implemented ✅
- [x] Onboarding flow (3 steps)
- [x] Home feed with posts & stories
- [x] Product details with KSh pricing
- [x] Image carousel
- [x] Bottom tab navigation
- [x] Authentication (signup/login)
- [x] Product listings (CRUD)
- [x] Social posts (create, like, comment)
- [x] Orders management
- [x] Real-time chat (WebSocket)
- [x] M-Pesa payment integration
- [x] Notifications
- [x] User profiles

### To Complete 🚧
- [ ] Categories screen UI
- [ ] New listing form UI
- [ ] My listings screen UI
- [ ] Profile screen UI
- [ ] Create post screen UI
- [ ] Messages/chat UI
- [ ] Image upload (Cloudinary)
- [ ] Push notifications (Expo)
- [ ] Search functionality
- [ ] Favorites/bookmarks UI
- [ ] Product reviews

---

## 🎨 Design System

### Colors
- **Primary**: `#f45925` (Vasiti Orange)
- **Background**: `#ffffff` (White)
- **Text**: `#181311` (Dark Brown)
- **Secondary Text**: `#8a6b60` (Light Brown)
- **Border**: `#e6ddd9` (Light Beige)

### Typography
- **Primary Font**: Epilogue (headings, buttons)
- **Secondary Font**: Lato (body text)

### Components
- **Rounded corners**: 12-16px
- **Buttons**: Linear gradient orange with shadow
- **Cards**: White background with soft shadows
- **Icons**: Ionicons

---

## 🔌 API Endpoints

Base URL: `http://localhost:3000/api`

### Authentication
- `POST /auth/signup` - Register new user
- `POST /auth/login` - Login
- `GET /auth/me` - Get current user

### Products
- `GET /products` - List products (supports filters)
- `GET /products/:id` - Get product details
- `POST /products` - Create listing (auth required)
- `PUT /products/:id` - Update listing
- `DELETE /products/:id` - Delete listing

### Posts
- `GET /posts` - Get social feed
- `POST /posts` - Create post
- `POST /posts/:id/like` - Like/unlike post
- `POST /posts/:id/comment` - Add comment

### Orders
- `POST /orders` - Create order
- `GET /orders/buyer` - Get user's purchases
- `GET /orders/seller` - Get user's sales

### Messages
- `GET /messages/conversations` - Get all chats
- `GET /messages/:partnerId` - Get conversation
- `POST /messages` - Send message
- WebSocket: `ws://localhost:3000` - Real-time chat

### Payments (M-Pesa)
- `POST /payments/mpesa/initiate` - Start payment
- `POST /payments/mpesa/callback` - M-Pesa webhook
- `GET /payments/:orderId/status` - Check payment status

See [Backend README](vasiti-backend/README.md) for full API documentation.

---

## 🗄️ Database Schema

### Main Tables:
- **users** - User accounts
- **products** - Marketplace listings
- **posts** - Social feed posts
- **stories** - 24-hour stories
- **orders** - Purchase orders
- **messages** - Chat messages
- **reviews** - Product/seller reviews
- **notifications** - Push notifications
- **favorites** - Saved products
- **likes** - Post likes
- **comments** - Post comments

See [prisma/schema.prisma](vasiti-backend/prisma/schema.prisma) for full schema.

---

## 📦 Building for Production

### Android APK
```bash
cd vasiti-app

# Configure EAS
eas build:configure

# Build APK
eas build --platform android --profile production

# Download APK
eas build:download --platform android --latest
```

### Deploy Backend
```bash
cd vasiti-backend

# Push to GitHub
git push origin main

# Deploy to Railway (or Heroku)
# Follow DEPLOYMENT.md guide
```

See [DEPLOYMENT.md](DEPLOYMENT.md) for complete deployment steps.

---

## 💰 Estimated Costs (Kenya)

### Monthly Running Costs:
- **Railway Backend**: $5-20/month (free starter tier available)
- **PostgreSQL Database**: Included with Railway
- **Cloudinary (Images)**: Free tier (25GB storage)
- **Domain (.co.ke)**: KSh 1,500/year (~$12/year)
- **M-Pesa Transaction Fees**: 1-2% per transaction
- **Expo Build Service**: Free (limited) or $29/month

### One-Time Costs:
- **Google Play Developer**: $25 (one-time)
- **Apple Developer**: $99/year

**Total to Launch**: ~$30-50/month (production-ready)

---

## 🧪 Testing

### Backend Tests
```bash
cd vasiti-backend
npm run test
```

### Mobile App Tests
```bash
cd vasiti-app
npm run test
```

### M-Pesa Sandbox Testing
```bash
# Use test credentials in .env:
MPESA_ENVIRONMENT=sandbox
MPESA_SHORTCODE=174379

# Test phone numbers:
254708374149  # PIN: 1234
254708374150  # PIN: 1234

# Test with small amounts (1-50,000 KSh)
```

---

## 🐛 Troubleshooting

### Common Issues:

**Node.js not installed**:
- Download from https://nodejs.org/ (v20.x LTS)
- Restart terminal after installation

**Database connection failed**:
- Check `DATABASE_URL` in `.env`
- Ensure PostgreSQL is running
- Verify firewall allows connections

**M-Pesa payment failed**:
- Check phone number format: `254XXXXXXXXX`
- Verify API credentials are correct
- Ensure callback URL is accessible
- Test in sandbox first

**Expo build failed**:
- Clear cache: `expo start -c`
- Update dependencies: `npm update`
- Check EAS build logs: `eas build:list`

See [SETUP-INSTRUCTIONS.md](SETUP-INSTRUCTIONS.md) for more troubleshooting.

---

## 📄 License

This project is proprietary software for Vasiti Kenya.

---

## 👥 Contributors

Built by the Vasiti team for Kenyan university students.

---

## 📧 Support

For setup help or questions:
1. Check [SETUP-INSTRUCTIONS.md](SETUP-INSTRUCTIONS.md)
2. See [DEPLOYMENT.md](DEPLOYMENT.md)
3. Review backend/app README files

---

## 🗺️ Roadmap

### Phase 1: MVP (Current)
- [x] Core marketplace functionality
- [x] Social feed
- [x] M-Pesa payments
- [x] Real-time chat

### Phase 2: Enhancement (Next)
- [ ] Complete all placeholder screens
- [ ] Image upload functionality
- [ ] Push notifications
- [ ] Search & filters
- [ ] Reviews & ratings UI

### Phase 3: Scale (Future)
- [ ] iOS version
- [ ] University verification
- [ ] Event ticketing
- [ ] In-app wallet
- [ ] Analytics dashboard
- [ ] Admin panel

---

**Ready to deploy Vasiti in Kenya! 🇰🇪 🚀**

Start with [SETUP-INSTRUCTIONS.md](SETUP-INSTRUCTIONS.md) for local development.
