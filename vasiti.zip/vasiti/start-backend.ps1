# Start Backend Development Server
Write-Host "🚀 Starting Vasiti Backend..." -ForegroundColor Cyan

$backendPath = "c:\Users\kevooh\Desktop\vasiti\vasiti-backend"

if (Test-Path $backendPath) {
    Set-Location $backendPath
    
    # Check if node_modules exists
    if (-not (Test-Path "node_modules")) {
        Write-Host "⚠️  Dependencies not installed. Running npm install..." -ForegroundColor Yellow
        npm install
    }
    
    # Check if .env exists
    if (-not (Test-Path ".env")) {
        Write-Host "❌ .env file not found!" -ForegroundColor Red
        Write-Host "Please copy .env.example to .env and fill in your credentials" -ForegroundColor Yellow
        exit
    }
    
    Write-Host "✅ Starting backend server at http://localhost:3000/api" -ForegroundColor Green
    Write-Host "Press Ctrl+C to stop`n" -ForegroundColor Gray
    
    npm run dev
} else {
    Write-Host "❌ Backend folder not found at $backendPath" -ForegroundColor Red
}
