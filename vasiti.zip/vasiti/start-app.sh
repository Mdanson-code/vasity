#!/bin/bash

# Start Vasiti Mobile App Development Server

echo "📱 Starting Vasiti Mobile App..."

APP_PATH="$PWD/vasiti-app"

if [ -d "$APP_PATH" ]; then
    cd "$APP_PATH"
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        echo "⚠️  Dependencies not installed. Running npm install..."
        npm install
    fi
    
    echo "✅ Starting Expo development server..."
    echo "Scan the QR code with Expo Go app on your phone"
    echo "Or press 'a' for Android emulator"
    echo ""
    
    npx expo start
else
    echo "❌ Mobile app folder not found at $APP_PATH"
fi
