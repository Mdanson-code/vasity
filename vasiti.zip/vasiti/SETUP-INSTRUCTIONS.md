# 🚀 Vasiti App - Setup Instructions

## Prerequisites Installation

### 1. Install Node.js (Required)
1. Download from: https://nodejs.org/ (LTS version 20.x)
2. Run installer
3. Restart VS Code terminal after installation
4. Verify: `node --version` (should show v20.x.x)

### 2. Install Expo CLI
```bash
npm install -g expo-cli eas-cli
```

### 3. Install Android Studio (for APK building)
1. Download from: https://developer.android.com/studio
2. Install Android SDK
3. Set up emulator or connect physical device

---

## 🏗️ Project Setup (Run After Node.js Installation)

### Mobile App Setup
```bash
cd c:\Users\kevooh\Desktop\vasiti\vasiti-app
npm install
npx expo start
```

### Backend Setup
```bash
cd c:\Users\kevooh\Desktop\vasiti\vasiti-backend
npm install
npm run dev
```

---

## 📱 Running the App

### Development Mode
```bash
cd vasiti-app
npx expo start

# Options:
# - Press 'a' for Android emulator
# - Press 'i' for iOS simulator (Mac only)
# - Scan QR code with Expo Go app on phone
```

### Build APK for Production
```bash
cd vasiti-app
eas build --platform android --profile production
```

---

## 🔧 Tech Stack

### Mobile App
- **React Native + Expo** - Cross-platform mobile
- **TypeScript** - Type safety
- **React Navigation** - Navigation
- **React Query** - Data fetching
- **Zustand** - State management
- **NativeWind** - Tailwind for React Native

### Backend
- **NestJS** - Node.js framework
- **PostgreSQL** - Database
- **Prisma** - ORM
- **Passport JWT** - Authentication
- **Cloudinary** - Image storage

### Payments
- **M-Pesa (Safaricom)** - Kenya mobile money
- **Daraja API** - M-Pesa integration

---

## 💰 Currency
All prices in **KSh (Kenyan Shillings)**

---

## 📁 Project Structure

```
vasiti-app/                    # Mobile app (React Native)
├── src/
│   ├── screens/              # All app screens
│   ├── components/           # Reusable components
│   ├── navigation/           # Navigation config
│   ├── services/             # API calls
│   ├── store/                # State management
│   ├── utils/                # Helpers
│   └── types/                # TypeScript types
├── assets/                   # Images, fonts
└── app.json                  # Expo config

vasiti-backend/               # Backend API (NestJS)
├── src/
│   ├── auth/                 # Authentication
│   ├── users/                # User management
│   ├── products/             # Product listings
│   ├── orders/               # Order processing
│   ├── posts/                # Social posts
│   ├── messages/             # Chat system
│   └── payments/             # M-Pesa integration
├── prisma/
│   └── schema.prisma         # Database schema
└── .env                      # Environment variables
```

---

## 🔐 Environment Variables Needed

### Backend (.env)
```
DATABASE_URL="postgresql://user:password@localhost:5432/vasiti"
JWT_SECRET="your-secret-key"
CLOUDINARY_CLOUD_NAME="your-cloudinary-name"
CLOUDINARY_API_KEY="your-api-key"
CLOUDINARY_API_SECRET="your-api-secret"
MPESA_CONSUMER_KEY="your-mpesa-key"
MPESA_CONSUMER_SECRET="your-mpesa-secret"
MPESA_SHORTCODE="your-shortcode"
```

### Mobile App (.env)
```
API_URL="http://localhost:3000"
```

---

## 📊 Next Steps After Node.js Installation

I've created the full project structure. After installing Node.js:

1. Run `npm install` in both folders
2. Set up PostgreSQL database
3. Run database migrations
4. Start development servers
5. Test on your phone with Expo Go app

---

## 🎯 Features Being Built

✅ User authentication (signup/login)  
✅ Product listings (create/edit/delete)  
✅ Social feed with posts  
✅ Stories (24hr expiry)  
✅ Real-time messaging  
✅ M-Pesa payments  
✅ Search & filters  
✅ Reviews & ratings  
✅ Push notifications  
✅ Complete navigation  

---

## 🏗️ Current Status

**Project structure created** ✅  
**Need Node.js installed to continue** ⏳  

Once Node.js is installed, I'll:
1. Initialize both projects with dependencies
2. Build all screens from the designs
3. Connect to backend APIs
4. Set up M-Pesa payments
5. Build production APK

---

**Ready to continue after Node.js installation! 🚀**
