import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { MessagesService } from './messages.service';

@WebSocketGateway({ cors: true })
export class MessagesGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server: Server;

  private connectedUsers = new Map<string, string>(); // userId -> socketId

  constructor(private messagesService: MessagesService) {}

  handleConnection(client: Socket) {
    const userId = client.handshake.query.userId as string;
    if (userId) {
      this.connectedUsers.set(userId, client.id);
      console.log(`User ${userId} connected`);
    }
  }

  handleDisconnect(client: Socket) {
    const userId = Array.from(this.connectedUsers.entries()).find(
      ([, socketId]) => socketId === client.id,
    )?.[0];
    if (userId) {
      this.connectedUsers.delete(userId);
      console.log(`User ${userId} disconnected`);
    }
  }

  @SubscribeMessage('send_message')
  async handleMessage(client: Socket, payload: any) {
    const message = await this.messagesService.sendMessage({
      senderId: payload.senderId,
      recipientId: payload.recipientId,
      content: payload.content,
      attachmentUrl: payload.attachmentUrl,
    });

    // Send to recipient if online
    const recipientSocketId = this.connectedUsers.get(payload.recipientId);
    if (recipientSocketId) {
      this.server.to(recipientSocketId).emit('new_message', message);
    }

    // Send confirmation to sender
    client.emit('message_sent', message);

    return message;
  }

  @SubscribeMessage('typing')
  handleTyping(client: Socket, payload: { recipientId: string; isTyping: boolean }) {
    const recipientSocketId = this.connectedUsers.get(payload.recipientId);
    if (recipientSocketId) {
      this.server.to(recipientSocketId).emit('user_typing', {
        isTyping: payload.isTyping,
      });
    }
  }
}
