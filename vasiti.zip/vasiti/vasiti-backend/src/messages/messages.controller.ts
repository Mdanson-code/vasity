import { Controller, Get, Post, Body, Param, UseGuards } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@Controller('messages')
export class MessagesController {
  constructor(private messagesService: MessagesService) {}

  @Get('conversations')
  @UseGuards(JwtAuthGuard)
  async getConversations(@CurrentUser() user: any) {
    return this.messagesService.getConversations(user.id);
  }

  @Get(':partnerId')
  @UseGuards(JwtAuthGuard)
  async getMessages(@CurrentUser() user: any, @Param('partnerId') partnerId: string) {
    return this.messagesService.getMessages(user.id, partnerId);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  async sendMessage(
    @CurrentUser() user: any,
    @Body() body: { recipientId: string; content: string; attachmentUrl?: string },
  ) {
    return this.messagesService.sendMessage({
      senderId: user.id,
      ...body,
    });
  }
}
