import { Controller, Get, Post, Put, Body, Param, UseGuards } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@Controller('orders')
export class OrdersController {
  constructor(private ordersService: OrdersService) {}

  @Post()
  @UseGuards(JwtAuthGuard)
  async createOrder(
    @CurrentUser() user: any,
    @Body()
    body: {
      productId: string;
      amount: number;
      shippingAddress: string;
    },
  ) {
    return this.ordersService.create({
      ...body,
      buyerId: user.id,
    });
  }

  @Get('buyer')
  @UseGuards(JwtAuthGuard)
  async getBuyerOrders(@CurrentUser() user: any) {
    return this.ordersService.findByBuyer(user.id);
  }

  @Get('seller')
  @UseGuards(JwtAuthGuard)
  async getSellerOrders(@CurrentUser() user: any) {
    return this.ordersService.findBySeller(user.id);
  }

  @Put(':id/status')
  @UseGuards(JwtAuthGuard)
  async updateOrderStatus(@Param('id') id: string, @Body() body: { status: string }) {
    return this.ordersService.updateStatus(id, body.status);
  }
}
