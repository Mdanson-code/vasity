import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService) {}

  async create(data: {
    buyerId: string;
    productId: string;
    amount: number;
    shippingAddress: string;
  }) {
    // Get product to verify availability and get seller
    const product = await this.prisma.product.findUnique({
      where: { id: data.productId },
    });

    if (!product || product.status !== 'active') {
      throw new NotFoundException('Product not available');
    }

    return this.prisma.order.create({
      data: {
        ...data,
        sellerId: product.sellerId,
        status: 'pending',
      },
      include: {
        product: true,
        buyer: {
          select: {
            id: true,
            fullName: true,
            username: true,
            phone: true,
          },
        },
        seller: {
          select: {
            id: true,
            fullName: true,
            username: true,
            phone: true,
          },
        },
      },
    });
  }

  async findByBuyer(buyerId: string) {
    return this.prisma.order.findMany({
      where: { buyerId },
      orderBy: { createdAt: 'desc' },
      include: {
        product: true,
        seller: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
          },
        },
      },
    });
  }

  async findBySeller(sellerId: string) {
    return this.prisma.order.findMany({
      where: { sellerId },
      orderBy: { createdAt: 'desc' },
      include: {
        product: true,
        buyer: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            phone: true,
          },
        },
      },
    });
  }

  async updateStatus(orderId: string, status: string) {
    return this.prisma.order.update({
      where: { id: orderId },
      data: {
        status,
        ...(status === 'completed' && { completedAt: new Date() }),
      },
    });
  }

  async updatePayment(orderId: string, transactionId: string, paymentMethod: string) {
    return this.prisma.order.update({
      where: { id: orderId },
      data: {
        status: 'paid',
        transactionId,
        paymentMethod,
      },
    });
  }
}
