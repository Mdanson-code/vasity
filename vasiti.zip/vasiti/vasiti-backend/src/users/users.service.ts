import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  async findById(id: string) {
    return this.prisma.user.findUnique({
      where: { id },
      select: {
        id: true,
        email: true,
        fullName: true,
        username: true,
        avatar: true,
        bio: true,
        university: true,
        location: true,
        verified: true,
        createdAt: true,
      },
    });
  }

  async findByUsername(username: string) {
    return this.prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        fullName: true,
        username: true,
        avatar: true,
        bio: true,
        verified: true,
        _count: {
          select: {
            products: true,
            posts: true,
          },
        },
      },
    });
  }

  async updateProfile(
    userId: string,
    data: {
      fullName?: string;
      bio?: string;
      avatar?: string;
      university?: string;
      location?: string;
    },
  ) {
    return this.prisma.user.update({
      where: { id: userId },
      data,
      select: {
        id: true,
        email: true,
        fullName: true,
        username: true,
        avatar: true,
        bio: true,
        university: true,
        location: true,
      },
    });
  }
}
