import { Controller, Get, Post, Body, Param, UseGuards, Query } from '@nestjs/common';
import { PostsService } from './posts.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@Controller('posts')
export class PostsController {
  constructor(private postsService: PostsService) {}

  @Get()
  async getFeed(@Query('limit') limit?: string) {
    return this.postsService.getFeed(undefined, limit ? parseInt(limit) : undefined);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  async createPost(
    @CurrentUser() user: any,
    @Body()
    body: {
      content?: string;
      images: string[];
      location?: string;
      hashtags?: string[];
    },
  ) {
    return this.postsService.create(user.id, body);
  }

  @Post(':id/like')
  @UseGuards(JwtAuthGuard)
  async likePost(@Param('id') postId: string, @CurrentUser() user: any) {
    return this.postsService.likePost(postId, user.id);
  }

  @Post(':id/comment')
  @UseGuards(JwtAuthGuard)
  async addComment(
    @Param('id') postId: string,
    @CurrentUser() user: any,
    @Body() body: { content: string },
  ) {
    return this.postsService.addComment(postId, user.id, body.content);
  }
}
