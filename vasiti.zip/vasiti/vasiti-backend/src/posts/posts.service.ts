import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class PostsService {
  constructor(private prisma: PrismaService) {}

  async getFeed(userId?: string, limit = 20) {
    return this.prisma.post.findMany({
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            verified: true,
          },
        },
        _count: {
          select: {
            postLikes: true,
            comments: true,
          },
        },
      },
    });
  }

  async create(
    userId: string,
    data: {
      content?: string;
      images: string[];
      location?: string;
      hashtags?: string[];
    },
  ) {
    return this.prisma.post.create({
      data: {
        ...data,
        userId,
      },
      include: {
        user: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            verified: true,
          },
        },
      },
    });
  }

  async likePost(postId: string, userId: string) {
    // Check if already liked
    const existing = await this.prisma.like.findUnique({
      where: {
        userId_postId: {
          userId,
          postId,
        },
      },
    });

    if (existing) {
      // Unlike
      await this.prisma.like.delete({
        where: {
          userId_postId: {
            userId,
            postId,
          },
        },
      });
      await this.prisma.post.update({
        where: { id: postId },
        data: { likes: { decrement: 1 } },
      });
      return { liked: false };
    } else {
      // Like
      await this.prisma.like.create({
        data: {
          userId,
          postId,
        },
      });
      await this.prisma.post.update({
        where: { id: postId },
        data: { likes: { increment: 1 } },
      });
      return { liked: true };
    }
  }

  async addComment(postId: string, userId: string, content: string) {
    return this.prisma.comment.create({
      data: {
        postId,
        userId,
        content,
      },
      include: {
        user: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
          },
        },
      },
    });
  }
}
