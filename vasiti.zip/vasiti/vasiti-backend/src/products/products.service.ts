import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ProductsService {
  constructor(private prisma: PrismaService) {}

  async findAll(query: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    condition?: string;
    limit?: number;
  }) {
    const { category, search, minPrice, maxPrice, condition, limit = 20 } = query;

    const where: any = {
      status: 'active',
    };

    if (category) {
      where.category = category;
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ];
    }

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = minPrice;
      if (maxPrice) where.price.lte = maxPrice;
    }

    if (condition) {
      where.condition = condition;
    }

    return this.prisma.product.findMany({
      where,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        seller: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            verified: true,
          },
        },
        _count: {
          select: {
            favorites: true,
          },
        },
      },
    });
  }

  async findById(id: string) {
    const product = await this.prisma.product.findUnique({
      where: { id },
      include: {
        seller: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            verified: true,
            _count: {
              select: {
                products: true,
                reviewsReceived: true,
              },
            },
          },
        },
        _count: {
          select: {
            favorites: true,
          },
        },
      },
    });

    if (!product) {
      throw new NotFoundException('Product not found');
    }

    // Increment views
    await this.prisma.product.update({
      where: { id },
      data: { views: { increment: 1 } },
    });

    return product;
  }

  async create(
    userId: string,
    data: {
      title: string;
      description: string;
      price: number;
      category: string;
      condition: string;
      images: string[];
      location: string;
    },
  ) {
    return this.prisma.product.create({
      data: {
        ...data,
        currency: 'KSh',
        sellerId: userId,
      },
      include: {
        seller: {
          select: {
            id: true,
            fullName: true,
            username: true,
            avatar: true,
            verified: true,
          },
        },
      },
    });
  }

  async update(
    id: string,
    userId: string,
    data: {
      title?: string;
      description?: string;
      price?: number;
      condition?: string;
      images?: string[];
      status?: string;
    },
  ) {
    // Verify ownership
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product || product.sellerId !== userId) {
      throw new NotFoundException('Product not found or unauthorized');
    }

    return this.prisma.product.update({
      where: { id },
      data,
    });
  }

  async delete(id: string, userId: string) {
    const product = await this.prisma.product.findUnique({
      where: { id },
    });

    if (!product || product.sellerId !== userId) {
      throw new NotFoundException('Product not found or unauthorized');
    }

    await this.prisma.product.delete({
      where: { id },
    });

    return { message: 'Product deleted successfully' };
  }
}
