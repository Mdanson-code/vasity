import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ProductsService } from './products.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { CurrentUser } from '../auth/decorators/current-user.decorator';

@Controller('products')
export class ProductsController {
  constructor(private productsService: ProductsService) {}

  @Get()
  async getProducts(
    @Query('category') category?: string,
    @Query('search') search?: string,
    @Query('minPrice') minPrice?: string,
    @Query('maxPrice') maxPrice?: string,
    @Query('condition') condition?: string,
    @Query('limit') limit?: string,
  ) {
    return this.productsService.findAll({
      category,
      search,
      minPrice: minPrice ? parseFloat(minPrice) : undefined,
      maxPrice: maxPrice ? parseFloat(maxPrice) : undefined,
      condition,
      limit: limit ? parseInt(limit) : undefined,
    });
  }

  @Get(':id')
  async getProduct(@Param('id') id: string) {
    return this.productsService.findById(id);
  }

  @Post()
  @UseGuards(JwtAuthGuard)
  async createProduct(
    @CurrentUser() user: any,
    @Body()
    body: {
      title: string;
      description: string;
      price: number;
      category: string;
      condition: string;
      images: string[];
      location: string;
    },
  ) {
    return this.productsService.create(user.id, body);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard)
  async updateProduct(
    @Param('id') id: string,
    @CurrentUser() user: any,
    @Body()
    body: {
      title?: string;
      description?: string;
      price?: number;
      condition?: string;
      images?: string[];
      status?: string;
    },
  ) {
    return this.productsService.update(id, user.id, body);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  async deleteProduct(@Param('id') id: string, @CurrentUser() user: any) {
    return this.productsService.delete(id, user.id);
  }
}
