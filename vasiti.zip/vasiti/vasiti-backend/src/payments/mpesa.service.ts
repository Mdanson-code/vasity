import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';

@Injectable()
export class MpesaService {
  private readonly logger = new Logger(MpesaService.name);
  private readonly baseUrl: string;
  private readonly consumerKey: string;
  private readonly consumerSecret: string;
  private readonly shortcode: string;
  private readonly passkey: string;
  private readonly callbackUrl: string;

  constructor(private config: ConfigService) {
    const environment = this.config.get('MPESA_ENVIRONMENT') || 'sandbox';
    this.baseUrl =
      environment === 'production'
        ? 'https://api.safaricom.co.ke'
        : 'https://sandbox.safaricom.co.ke';

    this.consumerKey = this.config.get('MPESA_CONSUMER_KEY');
    this.consumerSecret = this.config.get('MPESA_CONSUMER_SECRET');
    this.shortcode = this.config.get('MPESA_SHORTCODE');
    this.passkey = this.config.get('MPESA_PASSKEY');
    this.callbackUrl = this.config.get('MPESA_CALLBACK_URL');
  }

  /**
   * Get OAuth access token from M-Pesa
   */
  private async getAccessToken(): Promise<string> {
    try {
      const auth = Buffer.from(`${this.consumerKey}:${this.consumerSecret}`).toString('base64');

      const response = await axios.get(`${this.baseUrl}/oauth/v1/generate?grant_type=client_credentials`, {
        headers: {
          Authorization: `Basic ${auth}`,
        },
      });

      return response.data.access_token;
    } catch (error) {
      this.logger.error('Failed to get M-Pesa access token:', error.message);
      throw new Error('Failed to authenticate with M-Pesa');
    }
  }

  /**
   * Generate password for Lipa Na M-Pesa Online
   */
  private generatePassword(): { password: string; timestamp: string } {
    const timestamp = new Date()
      .toISOString()
      .replace(/[^0-9]/g, '')
      .slice(0, 14);

    const password = Buffer.from(`${this.shortcode}${this.passkey}${timestamp}`).toString('base64');

    return { password, timestamp };
  }

  /**
   * Initiate STK Push (Lipa Na M-Pesa Online)
   * @param phoneNumber - Customer phone number (format: 254XXXXXXXXX)
   * @param amount - Amount in KSh
   * @param accountReference - Order ID or reference
   * @param transactionDesc - Description of transaction
   */
  async stkPush(
    phoneNumber: string,
    amount: number,
    accountReference: string,
    transactionDesc: string,
  ): Promise<any> {
    try {
      const accessToken = await this.getAccessToken();
      const { password, timestamp } = this.generatePassword();

      // Ensure phone number is in correct format (254XXXXXXXXX)
      const formattedPhone = phoneNumber.startsWith('254') ? phoneNumber : `254${phoneNumber.replace(/^0/, '')}`;

      const payload = {
        BusinessShortCode: this.shortcode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: 'CustomerPayBillOnline',
        Amount: Math.floor(amount), // M-Pesa requires integer
        PartyA: formattedPhone, // Customer phone
        PartyB: this.shortcode, // Business shortcode
        PhoneNumber: formattedPhone,
        CallBackURL: this.callbackUrl,
        AccountReference: accountReference,
        TransactionDesc: transactionDesc,
      };

      this.logger.log(`Initiating STK Push: ${JSON.stringify(payload)}`);

      const response = await axios.post(`${this.baseUrl}/mpesa/stkpush/v1/processrequest`, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      this.logger.log(`M-Pesa Response: ${JSON.stringify(response.data)}`);

      return {
        success: response.data.ResponseCode === '0',
        checkoutRequestId: response.data.CheckoutRequestID,
        merchantRequestId: response.data.MerchantRequestID,
        responseDescription: response.data.ResponseDescription,
        responseCode: response.data.ResponseCode,
      };
    } catch (error) {
      this.logger.error('M-Pesa STK Push failed:', error.response?.data || error.message);
      throw new Error('Failed to initiate M-Pesa payment');
    }
  }

  /**
   * Query STK Push status
   */
  async queryTransaction(checkoutRequestId: string): Promise<any> {
    try {
      const accessToken = await this.getAccessToken();
      const { password, timestamp } = this.generatePassword();

      const payload = {
        BusinessShortCode: this.shortcode,
        Password: password,
        Timestamp: timestamp,
        CheckoutRequestID: checkoutRequestId,
      };

      const response = await axios.post(`${this.baseUrl}/mpesa/stkpushquery/v1/query`, payload, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      return response.data;
    } catch (error) {
      this.logger.error('M-Pesa query failed:', error.response?.data || error.message);
      throw new Error('Failed to query M-Pesa transaction');
    }
  }

  /**
   * Process M-Pesa callback
   */
  processCallback(callbackData: any): {
    success: boolean;
    transactionId?: string;
    amount?: number;
    phoneNumber?: string;
    resultCode?: string;
    resultDesc?: string;
  } {
    try {
      const { Body } = callbackData;
      const { stkCallback } = Body;

      const success = stkCallback.ResultCode === 0;

      if (success && stkCallback.CallbackMetadata) {
        const metadata = stkCallback.CallbackMetadata.Item;
        const amount = metadata.find((item: any) => item.Name === 'Amount')?.Value;
        const transactionId = metadata.find((item: any) => item.Name === 'MpesaReceiptNumber')?.Value;
        const phoneNumber = metadata.find((item: any) => item.Name === 'PhoneNumber')?.Value;

        return {
          success: true,
          transactionId,
          amount,
          phoneNumber,
          resultCode: stkCallback.ResultCode.toString(),
          resultDesc: stkCallback.ResultDesc,
        };
      }

      return {
        success: false,
        resultCode: stkCallback.ResultCode.toString(),
        resultDesc: stkCallback.ResultDesc,
      };
    } catch (error) {
      this.logger.error('Failed to process M-Pesa callback:', error.message);
      return {
        success: false,
        resultDesc: 'Failed to process callback',
      };
    }
  }
}
