import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { MpesaService } from './mpesa.service';
import { OrdersService } from '../orders/orders.service';

@Injectable()
export class PaymentsService {
  private readonly logger = new Logger(PaymentsService.name);

  constructor(
    private prisma: PrismaService,
    private mpesaService: MpesaService,
    private ordersService: OrdersService,
  ) {}

  /**
   * Initiate M-Pesa payment for an order
   */
  async initiatePayment(orderId: string, phoneNumber: string) {
    // Get order details
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        product: true,
        buyer: true,
      },
    });

    if (!order) {
      throw new Error('Order not found');
    }

    // Initiate STK Push
    const result = await this.mpesaService.stkPush(
      phoneNumber,
      order.amount,
      orderId,
      `Payment for ${order.product.title}`,
    );

    // Store checkout request ID for later verification
    await this.prisma.order.update({
      where: { id: orderId },
      data: {
        transactionId: result.checkoutRequestId,
      },
    });

    return {
      success: result.success,
      checkoutRequestId: result.checkoutRequestId,
      message: 'Please check your phone for M-Pesa prompt',
    };
  }

  /**
   * Handle M-Pesa callback
   */
  async handleCallback(callbackData: any) {
    this.logger.log(`M-Pesa Callback received: ${JSON.stringify(callbackData)}`);

    const result = this.mpesaService.processCallback(callbackData);

    if (result.success) {
      // Find order by transaction ID or checkout request ID
      const order = await this.prisma.order.findFirst({
        where: {
          OR: [
            { transactionId: result.transactionId },
            { transactionId: callbackData.Body.stkCallback.CheckoutRequestID },
          ],
        },
      });

      if (order) {
        // Update order with payment details
        await this.ordersService.updatePayment(order.id, result.transactionId, 'mpesa');

        this.logger.log(`Order ${order.id} payment confirmed: ${result.transactionId}`);

        // Create notification for seller
        await this.prisma.notification.create({
          data: {
            userId: order.sellerId,
            type: 'order',
            title: 'New Order!',
            body: `You received a new order worth KSh ${order.amount}`,
            data: { orderId: order.id },
          },
        });

        // Create notification for buyer
        await this.prisma.notification.create({
          data: {
            userId: order.buyerId,
            type: 'order',
            title: 'Payment Successful',
            body: 'Your payment has been confirmed',
            data: { orderId: order.id },
          },
        });
      }
    } else {
      this.logger.error(`M-Pesa payment failed: ${result.resultDesc}`);
    }

    return { success: result.success };
  }

  /**
   * Check payment status
   */
  async checkPaymentStatus(orderId: string) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
    });

    if (!order || !order.transactionId) {
      return { status: 'unknown', message: 'No transaction found' };
    }

    // Query M-Pesa API
    const result = await this.mpesaService.queryTransaction(order.transactionId);

    return {
      status: result.ResultCode === '0' ? 'success' : 'pending',
      data: result,
    };
  }
}
