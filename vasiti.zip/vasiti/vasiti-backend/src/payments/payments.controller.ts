import { Controller, Post, Get, Body, Param, UseGuards, HttpCode } from '@nestjs/common';
import { PaymentsService } from './payments.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@Controller('payments')
export class PaymentsController {
  constructor(private paymentsService: PaymentsService) {}

  /**
   * Initiate M-Pesa payment
   * POST /api/payments/mpesa/initiate
   */
  @Post('mpesa/initiate')
  @UseGuards(JwtAuthGuard)
  async initiatePayment(
    @Body() body: { orderId: string; phoneNumber: string },
  ) {
    return this.paymentsService.initiatePayment(body.orderId, body.phoneNumber);
  }

  /**
   * M-Pesa callback endpoint
   * POST /api/payments/mpesa/callback
   * This is called by Safaricom servers - no auth required
   */
  @Post('mpesa/callback')
  @HttpCode(200)
  async mpesaCallback(@Body() body: any) {
    return this.paymentsService.handleCallback(body);
  }

  /**
   * Check payment status
   * GET /api/payments/:orderId/status
   */
  @Get(':orderId/status')
  @UseGuards(JwtAuthGuard)
  async checkStatus(@Param('orderId') orderId: string) {
    return this.paymentsService.checkPaymentStatus(orderId);
  }
}
