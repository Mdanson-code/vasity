# Vasiti Backend API

NestJS + PostgreSQL + Prisma backend for Vasiti mobile app

## Prerequisites

1. **Node.js** (v20.x LTS) - https://nodejs.org/
2. **PostgreSQL** (v14+) - https://www.postgresql.org/download/
3. **npm** or **yarn**

## Setup Instructions

### 1. Install Dependencies
```bash
cd vasiti-backend
npm install
```

### 2. Database Setup

#### Option A: Local PostgreSQL
1. Install PostgreSQL
2. Create database:
```sql
CREATE DATABASE vasiti;
```
3. Update `.env` with your database URL:
```
DATABASE_URL="postgresql://username:password@localhost:5432/vasiti?schema=public"
```

#### Option B: Cloud PostgreSQL (Recommended)
Use **Supabase** (free tier):
1. Go to https://supabase.com
2. Create new project
3. Get connection string from Settings → Database
4. Update `.env` with connection string

### 3. Environment Variables
```bash
cp .env.example .env
# Edit .env with your actual values
```

### 4. Run Migrations
```bash
npx prisma generate
npx prisma migrate dev --name init
```

### 5. Start Development Server
```bash
npm run dev
```

API will be available at: `http://localhost:3000/api`

## API Endpoints

### Authentication
- `POST /api/auth/signup` - Register new user
- `POST /api/auth/login` - Login
- `POST /api/auth/verify` - Verify email/phone
- `POST /api/auth/refresh` - Refresh JWT token

### Products
- `GET /api/products` - List all products
- `GET /api/products/:id` - Get product details
- `POST /api/products` - Create product (auth required)
- `PUT /api/products/:id` - Update product (auth required)
- `DELETE /api/products/:id` - Delete product (auth required)

### Posts (Social)
- `GET /api/posts` - Get feed
- `POST /api/posts` - Create post (auth required)
- `POST /api/posts/:id/like` - Like post
- `POST /api/posts/:id/comment` - Add comment

### Orders
- `POST /api/orders` - Create order
- `GET /api/orders/buyer` - Get user's purchases
- `GET /api/orders/seller` - Get user's sales
- `PUT /api/orders/:id/status` - Update order status

### Messages
- `GET /api/messages` - Get conversations
- `POST /api/messages` - Send message
- WebSocket: `ws://localhost:3000/messages` - Real-time chat

### Payments (M-Pesa)
- `POST /api/payments/mpesa/initiate` - Start M-Pesa payment
- `POST /api/payments/mpesa/callback` - M-Pesa callback (webhook)
- `GET /api/payments/:id/status` - Check payment status

## Database Schema

Prisma models:
- **User** - User accounts
- **Product** - Marketplace listings
- **Post** - Social feed posts
- **Story** - 24hr stories
- **Order** - Purchase orders
- **Message** - Chat messages
- **Review** - Product/seller reviews
- **Notification** - Push notifications
- **Favorite** - Saved products
- **Like** - Post likes
- **Comment** - Post comments

## M-Pesa Integration (Kenya)

### Getting M-Pesa Credentials
1. Go to https://developer.safaricom.co.ke/
2. Create account
3. Register app (Lipa Na M-Pesa Online)
4. Get:
   - Consumer Key
   - Consumer Secret
   - Business Shortcode
   - Passkey

### Testing M-Pesa (Sandbox)
```
Test Phone: 254708374149
Test Amount: 1 KSh
PIN: 1234 (in sandbox)
```

## Project Structure
```
src/
├── auth/           # Authentication & JWT
├── users/          # User management
├── products/       # Product listings
├── posts/          # Social posts
├── orders/         # Order processing
├── messages/       # Real-time chat
├── payments/       # M-Pesa integration
├── prisma/         # Database service
└── main.ts         # App entry point
```

## Development Commands

```bash
# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm run start:prod

# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# Open Prisma Studio (DB GUI)
npx prisma studio

# Lint code
npm run lint
```

## Deployment

### Recommended Platform: Railway.app
1. Push code to GitHub
2. Connect Railway to repo
3. Add PostgreSQL service
4. Set environment variables
5. Deploy!

### Alternative: Heroku, DigitalOcean, AWS

## Currency
All financial operations use **KSh (Kenyan Shillings)**

## Next Steps
1. Complete all module implementations
2. Add WebSocket for real-time features
3. Implement file upload (Cloudinary)
4. Set up M-Pesa integration
5. Add push notifications
6. Deploy to production

## Support
For setup help, see main SETUP-INSTRUCTIONS.md
