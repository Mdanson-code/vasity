# Vasiti Quick Start Script
# Run this script after installing Node.js

Write-Host "🚀 Vasiti Quick Start Setup" -ForegroundColor Cyan
Write-Host "================================`n" -ForegroundColor Cyan

# Check Node.js installation
Write-Host "Checking Node.js installation..." -ForegroundColor Yellow
try {
    $nodeVersion = node --version
    Write-Host "✅ Node.js $nodeVersion installed" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js not found. Please install from https://nodejs.org/" -ForegroundColor Red
    Write-Host "After installing, restart your terminal and run this script again." -ForegroundColor Yellow
    exit
}

# Check npm
try {
    $npmVersion = npm --version
    Write-Host "✅ npm $npmVersion installed`n" -ForegroundColor Green
} catch {
    Write-Host "❌ npm not found" -ForegroundColor Red
    exit
}

# Setup Backend
Write-Host "================================" -ForegroundColor Cyan
Write-Host "📦 Setting up Backend..." -ForegroundColor Cyan
Write-Host "================================`n" -ForegroundColor Cyan

$backendPath = "c:\Users\kevooh\Desktop\vasiti\vasiti-backend"
if (Test-Path $backendPath) {
    Set-Location $backendPath
    
    Write-Host "Installing backend dependencies... (this may take a few minutes)" -ForegroundColor Yellow
    npm install
    
    if (Test-Path ".env") {
        Write-Host "✅ .env file exists" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Creating .env file from .env.example..." -ForegroundColor Yellow
        Copy-Item ".env.example" ".env"
        Write-Host "✅ .env file created. Please edit it with your credentials." -ForegroundColor Green
    }
    
    Write-Host "`nGenerating Prisma client..." -ForegroundColor Yellow
    npx prisma generate
    
    Write-Host "`n✅ Backend setup complete!" -ForegroundColor Green
} else {
    Write-Host "❌ Backend folder not found at $backendPath" -ForegroundColor Red
}

Write-Host "`n================================" -ForegroundColor Cyan
Write-Host "📱 Setting up Mobile App..." -ForegroundColor Cyan
Write-Host "================================`n" -ForegroundColor Cyan

$appPath = "c:\Users\kevooh\Desktop\vasiti\vasiti-app"
if (Test-Path $appPath) {
    Set-Location $appPath
    
    Write-Host "Installing mobile app dependencies... (this may take a few minutes)" -ForegroundColor Yellow
    npm install
    
    Write-Host "`n✅ Mobile app setup complete!" -ForegroundColor Green
} else {
    Write-Host "❌ Mobile app folder not found at $appPath" -ForegroundColor Red
}

# Summary
Write-Host "`n================================" -ForegroundColor Cyan
Write-Host "🎉 Setup Complete!" -ForegroundColor Green
Write-Host "================================`n" -ForegroundColor Cyan

Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Set up PostgreSQL database" -ForegroundColor White
Write-Host "   - Option A: Install locally from https://www.postgresql.org/" -ForegroundColor Gray
Write-Host "   - Option B: Use Supabase (free): https://supabase.com`n" -ForegroundColor Gray

Write-Host "2. Update backend .env file:" -ForegroundColor White
Write-Host "   cd vasiti-backend" -ForegroundColor Gray
Write-Host "   notepad .env" -ForegroundColor Gray
Write-Host "   # Add your DATABASE_URL and other credentials`n" -ForegroundColor Gray

Write-Host "3. Run database migrations:" -ForegroundColor White
Write-Host "   cd vasiti-backend" -ForegroundColor Gray
Write-Host "   npx prisma migrate dev`n" -ForegroundColor Gray

Write-Host "4. Start backend server:" -ForegroundColor White
Write-Host "   cd vasiti-backend" -ForegroundColor Gray
Write-Host "   npm run dev" -ForegroundColor Gray
Write-Host "   # Backend will run at http://localhost:3000/api`n" -ForegroundColor DarkGray

Write-Host "5. Start mobile app (in new terminal):" -ForegroundColor White
Write-Host "   cd vasiti-app" -ForegroundColor Gray
Write-Host "   npx expo start" -ForegroundColor Gray
Write-Host "   # Scan QR code with Expo Go app`n" -ForegroundColor DarkGray

Write-Host "📚 Documentation:" -ForegroundColor Yellow
Write-Host "   - SETUP-INSTRUCTIONS.md - Complete setup guide" -ForegroundColor White
Write-Host "   - DEPLOYMENT.md - Production deployment" -ForegroundColor White
Write-Host "   - README.md - Project overview`n" -ForegroundColor White

Write-Host "Need help? Check SETUP-INSTRUCTIONS.md" -ForegroundColor Cyan
