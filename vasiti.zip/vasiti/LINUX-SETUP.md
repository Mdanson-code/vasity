# Vasiti - Linux/macOS Setup Guide

## Quick Start for Linux/macOS/WSL

### Prerequisites
```bash
# Node.js v20.x LTS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version  # Should show v20.x
npm --version   # Should show v10.x
```

### 1. Navigate to Project
```bash
cd /path/to/vasiti
```

### 2. Make Scripts Executable
```bash
chmod +x quick-start.sh start-backend.sh start-app.sh
```

### 3. Run Quick Start
```bash
./quick-start.sh
```

### 4. Set Up Database

#### Option A: Supabase (Free, Easy)
```bash
# 1. Go to https://supabase.com
# 2. Create new project
# 3. Get connection string from Settings → Database
# 4. Add to vasiti-backend/.env:
DATABASE_URL="postgresql://postgres:[PASSWORD]@[HOST]:5432/postgres"
```

#### Option B: Local PostgreSQL
```bash
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo -u postgres psql
CREATE DATABASE vasiti;
\q

# Add to .env:
DATABASE_URL="postgresql://postgres:password@localhost:5432/vasiti"
```

### 5. Configure & Migrate
```bash
cd vasiti-backend
nano .env  # Add your credentials
npx prisma migrate dev --name init
```

### 6. Start Servers
```bash
# Terminal 1
./start-backend.sh

# Terminal 2
./start-app.sh
```

---

## Building for Production

### Android APK
```bash
cd vasiti-app
npm install -g eas-cli
eas login
eas build --platform android --profile production
```

### Deploy Backend
```bash
# Push to GitHub then deploy on Railway.app
git init
git add .
git commit -m "Initial commit"
git push origin main
```

---

## Quick Commands

```bash
# Backend dev
cd vasiti-backend && npm run dev

# Mobile app dev
cd vasiti-app && npx expo start

# Database GUI
cd vasiti-backend && npx prisma studio

# Build APK
cd vasiti-app && eas build --platform android
```

---

For detailed instructions, see SETUP-INSTRUCTIONS.md and DEPLOYMENT.md
