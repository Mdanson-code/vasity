# 🎯 Supabase Database Setup - Quick Guide

## ✅ YOUR SUPABASE PROJECT

**Project URL:** `https://xenxbippfjlsfhcnljzr.supabase.co`  
**API Key (Publishable):** `sb_publishable_FFC7D2NDgI8bwdjmZminVg_jh801Q4q`

---

## 📋 Step 1: Get Your Database Password

1. Go to: https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/settings/database
2. Scroll to **Connection string**
3. Select **URI** tab
4. Click **Copy** (it will look like this):
   ```
   postgresql://postgres.xenxbippfjlsfhcnljzr:[YOUR-PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres
   ```
5. **Save your password** - you'll need it for the .env file

---

## 📋 Step 2: Configure Backend .env File

On your **Linux machine**, create `vasiti-backend/.env`:

```bash
# Navigate to backend folder
cd vasiti/vasiti-backend

# Create .env file
nano .env
```

**Paste this configuration** (replace `[YOUR-PASSWORD]` with your actual Supabase password):

```env
# Database - SUPABASE
DATABASE_URL="postgresql://postgres.xenxbippfjlsfhcnljzr:[YOUR-PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres"

# JWT
JWT_SECRET="vasiti-kenya-super-secret-jwt-key-2024-change-me"
JWT_EXPIRES_IN="7d"

# Cloudinary (Optional - for image upload)
CLOUDINARY_CLOUD_NAME=""
CLOUDINARY_API_KEY=""
CLOUDINARY_API_SECRET=""

# M-Pesa Sandbox (Test Credentials)
MPESA_CONSUMER_KEY="VwGp9G4K2G3xGEkAJG3A9F7N5A6KP8UA"
MPESA_CONSUMER_SECRET="YourConsumerSecretFromSafaricom"
MPESA_SHORTCODE="174379"
MPESA_PASSKEY="bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919"
MPESA_CALLBACK_URL="https://your-backend-url.railway.app/api/payments/mpesa/callback"
MPESA_ENVIRONMENT="sandbox"

# API
PORT=3000
API_URL="http://localhost:3000"

# Frontend
FRONTEND_URL="http://localhost:8081"

# Email (Optional)
SENDGRID_API_KEY=""
EMAIL_FROM="noreply@vasiti.app"

# SMS (Optional)
AFRICA_TALKING_API_KEY=""
AFRICA_TALKING_USERNAME=""
```

**Save:** Press `Ctrl+X`, then `Y`, then `Enter`

---

## 📋 Step 3: Run Database Migrations

```bash
# Still in vasiti-backend folder
npx prisma migrate dev --name init
```

This will create all 13 tables in your Supabase database:
- users
- products  
- posts
- orders
- messages
- payments
- reviews
- favorites
- notifications
- followers
- product_images
- post_images
- order_items

---

## 📋 Step 4: Verify Database Setup

```bash
# Open Prisma Studio to see your database
npx prisma studio
```

Or check directly in Supabase:
1. Go to: https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/editor
2. You should see all 13 tables listed on the left

---

## 🚀 Step 5: Start Backend

```bash
# From vasiti folder
./start-backend.sh
```

You should see:
```
[Nest] INFO  Nest application successfully started
[Nest] INFO  🚀 Server running on: http://localhost:3000
```

---

## 🧪 Step 6: Test API

Open a new terminal and test:

```bash
# Health check
curl http://localhost:3000

# Create a test user
curl -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@vasiti.com",
    "password": "Test1234!",
    "fullName": "Test User",
    "phone": "+254712345678",
    "university": "University of Nairobi"
  }'
```

---

## 📊 Supabase Dashboard Links

### Database Tables
https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/editor

### SQL Editor (Run queries)
https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/sql/new

### Database Settings
https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/settings/database

### API Settings
https://supabase.com/dashboard/project/xenxbippfjlsfhcnljzr/settings/api

---

## 🔒 Security Notes

### ✅ Safe to Share (Already Public)
- Project URL: `https://xenxbippfjlsfhcnljzr.supabase.co`
- Publishable API Key: `sb_publishable_FFC7D2NDgI8bwdjmZminVg_jh801Q4q`

### ⚠️ NEVER SHARE (Keep Secret)
- Database password
- Service role key (from Supabase dashboard)
- JWT_SECRET
- M-Pesa credentials (when you get production keys)

---

## 🐛 Troubleshooting

### "Can't reach database server"
**Solution:** Check your DATABASE_URL format:
```env
# Correct format (note the postgres.xenxbippfjlsfhcnljzr prefix)
DATABASE_URL="postgresql://postgres.xenxbippfjlsfhcnljzr:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres"
```

### "Authentication failed"
**Solution:** Password is wrong. Get it from Supabase dashboard:
1. Go to Settings > Database
2. Reset database password if needed
3. Update .env file

### "Prisma migrate fails"
**Solution:** 
```bash
# Delete migrations folder
rm -rf prisma/migrations

# Reset and create fresh
npx prisma migrate dev --name init
```

### "Tables already exist"
**Solution:** Supabase creates some default tables. This is fine - Prisma will skip them.

---

## 📱 Connect Mobile App to Backend

When backend is running, update your mobile app:

### For Local Testing (Expo on same network)
1. Get your local IP: `ip addr show` (look for 192.168.x.x)
2. Update `vasiti-app/app.json`:
   ```json
   "extra": {
     "API_URL": "http://192.168.1.100:3000"
   }
   ```

### For Production (Railway deployment)
1. Deploy backend to Railway (see DEPLOYMENT.md)
2. Update `vasiti-app/app.json`:
   ```json
   "extra": {
     "API_URL": "https://your-backend.railway.app"
   }
   ```

---

## ✅ Checklist

- [ ] Got Supabase database password
- [ ] Created .env file with correct DATABASE_URL
- [ ] Ran `npx prisma migrate dev`
- [ ] Verified 13 tables in Supabase dashboard
- [ ] Started backend successfully
- [ ] Tested API with curl
- [ ] Mobile app connected to backend

---

## 🎉 You're Ready!

Your Supabase database is now connected to your Vasiti backend. All 13 tables are created and ready to store:
- Users & authentication
- Products & listings
- Posts & social feed
- Orders & transactions
- Messages & chat
- M-Pesa payments
- Reviews & favorites

**Next:** Start your mobile app with `./start-app.sh` and begin testing! 🚀

---

*Last Updated: December 25, 2025*
